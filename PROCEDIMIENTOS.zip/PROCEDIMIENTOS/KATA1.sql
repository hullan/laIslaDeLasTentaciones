DELIMITER //

DROP PROCEDURE IF EXISTS insertar_presentador //

CREATE PROCEDURE insertar_presentador(IN p_nombre VARCHAR(255))
BEGIN
    INSERT INTO presentadores (nombre) VALUES (p_nombre);
END //

DELIMITER ;
