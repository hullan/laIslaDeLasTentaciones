DELIMITER //


DROP PROCEDURE IF EXISTS informe_parejas //

CREATE PROCEDURE informe_parejas(IN p_id_edicion INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_id_chico, v_id_chica INT;
    DECLARE v_nombre_chico, v_nombre_chica VARCHAR(255);
    DECLARE v_tiempo_juntos INT;
    DECLARE v_decision_final CHAR(1);
    
    DECLARE cur CURSOR FOR 
        SELECT p.id_chico, p.id_chica, c1.nombre, c2.nombre, p.tiempo_juntos, p.decision_final
        FROM parejas p
        JOIN concursantes c1 ON p.id_chico = c1.id
        JOIN concursantes c2 ON p.id_chica = c2.id
        WHERE c1.id_edicion = p_id_edicion;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO v_id_chico, v_id_chica, v_nombre_chico, v_nombre_chica, v_tiempo_juntos, v_decision_final;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SELECT CONCAT('Pareja: ', v_nombre_chico, ' y ', v_nombre_chica, 
                      ', Tiempo juntos: ', v_tiempo_juntos, ' meses',
                      ', Decisión final: ', IFNULL(v_decision_final, 'Pendiente')) AS informe;
    END LOOP;
    
    CLOSE cur;
END //

DELIMITER ;
