DELIMITER //

DROP PROCEDURE IF EXISTS simular_hoguera //

CREATE PROCEDURE simular_hoguera(IN p_id_edicion INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_id_chico, v_id_chica INT;
    DECLARE v_tiempo_juntos INT;
    DECLARE v_decision CHAR(1);
    DECLARE v_parejas_juntas, v_parejas_separadas INT DEFAULT 0;
    DECLARE v_tiempo_total INT DEFAULT 0;
    DECLARE v_total_parejas INT DEFAULT 0;
    
    DECLARE cur CURSOR FOR 
        SELECT p.id_chico, p.id_chica, p.tiempo_juntos
        FROM parejas p
        JOIN concursantes c ON p.id_chico = c.id
        WHERE c.id_edicion = p_id_edicion AND p.decision_final IS NULL;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    START TRANSACTION;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO v_id_chico, v_id_chica, v_tiempo_juntos;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SET v_decision = IF(RAND() > 0.5, 'J', 'S');
        
        UPDATE parejas
        SET decision_final = v_decision
        WHERE id_chico = v_id_chico AND id_chica = v_id_chica;
        
        IF v_decision = 'J' THEN
            SET v_parejas_juntas = v_parejas_juntas + 1;
        ELSE
            SET v_parejas_separadas = v_parejas_separadas + 1;
        END IF;
        
        SET v_tiempo_total = v_tiempo_total + v_tiempo_juntos;
        SET v_total_parejas = v_total_parejas + 1;
    END LOOP;
    
    CLOSE cur;
    
    UPDATE estadisticas_parejas_edicion
    SET parejas_juntas = v_parejas_juntas,
        parejas_separadas = v_parejas_separadas,
        tiempo_medio_relacion = v_tiempo_total / v_total_parejas
    WHERE id_edicion = p_id_edicion;
    
    COMMIT;
END //

DELIMITER ;
