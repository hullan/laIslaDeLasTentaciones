DELIMITER //

DROP PROCEDURE IF EXISTS registrar_pareja //

CREATE PROCEDURE registrar_pareja(
    IN p_id_chico INT,
    IN p_id_chica INT,
    IN p_id_edicion INT
)
BEGIN
    DECLARE pareja_existente CONDITION FOR SQLSTATE '45000';
    DECLARE EXIT HANDLER FOR pareja_existente
    BEGIN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Uno o ambos concursantes ya están en una pareja';
    END;

    IF EXISTS (SELECT 1 FROM parejas WHERE id_chico = p_id_chico OR id_chica = p_id_chico
               OR id_chico = p_id_chica OR id_chica = p_id_chica) THEN
        SIGNAL pareja_existente;
    ELSE
        INSERT INTO parejas (id_chico, id_chica, tiempo_juntos, decision_final)
        VALUES (p_id_chico, p_id_chica, 0, NULL);
    END IF;
END //

DELIMITER ;
