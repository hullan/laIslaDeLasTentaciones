DELIMITER //

DROP PROCEDURE IF EXISTS eliminar_pretendientes //

CREATE PROCEDURE eliminar_pretendientes(
    IN p_id_edicion INT,
    OUT p_pretendientes_eliminados INT
)
BEGIN
    DELETE FROM pretendientes
    WHERE id_edicion = p_id_edicion;

    SET p_pretendientes_eliminados = ROW_COUNT();
END //

DELIMITER ;
