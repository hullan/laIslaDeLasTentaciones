DELIMITER //

DROP TRIGGER IF EXISTS gestionar_pretendiente_ediciones //

CREATE TRIGGER gestionar_pretendiente_ediciones
BEFORE INSERT ON pretendientes
FOR EACH ROW
BEGIN
    DECLARE edicion_anterior INT;
    
    SELECT id_edicion INTO edicion_anterior
    FROM pretendientes
    WHERE id = NEW.id AND fecha_expulsion IS NULL;
    
    IF edicion_anterior IS NOT NULL THEN
        UPDATE pretendientes
        SET fecha_expulsion = CURDATE()
        WHERE id = NEW.id AND id_edicion = edicion_anterior;
    END IF;
END //

DELIMITER ;
