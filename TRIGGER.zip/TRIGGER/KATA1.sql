DELIMITER //

DROP TRIGGER IF EXISTS actualizar_fecha_decision //

CREATE TRIGGER actualizar_fecha_decision
BEFORE UPDATE ON parejas
FOR EACH ROW
BEGIN
    IF NEW.decision_final != OLD.decision_final THEN
        SET NEW.fecha_decision = CURDATE();
    END IF;
END //

DELIMITER ;
