DELIMITER //

DROP TRIGGER IF EXISTS verificar_edad_concursante //

CREATE TRIGGER verificar_edad_concursante
BEFORE INSERT ON concursantes
FOR EACH ROW
BEGIN
    IF NEW.edad < 18 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Los concursantes deben ser mayores de 18 años';
    END IF;
END //

DELIMITER ;
