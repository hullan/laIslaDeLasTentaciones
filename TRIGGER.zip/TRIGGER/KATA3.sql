DROP TABLE IF EXISTS auditoria_episodios;

CREATE TABLE auditoria_episodios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    accion VARCHAR(10),
    id_episodio INT,
    fecha_emision_anterior DATE,
    fecha_emision_nueva DATE,
    audiencia_anterior DECIMAL(10,2),
    audiencia_nueva DECIMAL(10,2),
    usuario VARCHAR(50),
    fecha_cambio TIMESTAMP
);

DELIMITER //

DROP TRIGGER IF EXISTS auditar_cambios_episodios //

CREATE TRIGGER auditar_cambios_episodios
AFTER UPDATE ON episodios
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_episodios (accion, id_episodio, fecha_emision_anterior, fecha_emision_nueva, 
                                     audiencia_anterior, audiencia_nueva, usuario, fecha_cambio)
    VALUES ('UPDATE', NEW.id, OLD.fecha_emision, NEW.fecha_emision, 
            OLD.audiencia, NEW.audiencia, CURRENT_USER(), NOW());
END //

DELIMITER ;
