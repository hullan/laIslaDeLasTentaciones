DROP TABLE IF EXISTS estadisticas_parejas_edicion;

CREATE TABLE estadisticas_parejas_edicion (
    id_edicion INT PRIMARY KEY,
    total_parejas INT DEFAULT 0,
    parejas_juntas INT DEFAULT 0,
    parejas_separadas INT DEFAULT 0,
    tiempo_medio_relacion DECIMAL(10,2) DEFAULT 0
);

DELIMITER //

DROP TRIGGER IF EXISTS inicializar_estadisticas_edicion //
DROP TRIGGER IF EXISTS actualizar_estadisticas_insert //
DROP TRIGGER IF EXISTS actualizar_estadisticas_update //
DROP TRIGGER IF EXISTS actualizar_estadisticas_delete //

CREATE TRIGGER inicializar_estadisticas_edicion
AFTER INSERT ON ediciones
FOR EACH ROW
BEGIN
    INSERT INTO estadisticas_parejas_edicion (id_edicion) VALUES (NEW.id);
END //

CREATE TRIGGER actualizar_estadisticas_insert
AFTER INSERT ON parejas
FOR EACH ROW
BEGIN
    DECLARE id_edicion INT;
    SELECT id_edicion INTO id_edicion FROM concursantes WHERE id = NEW.id_chico LIMIT 1;
    
    UPDATE estadisticas_parejas_edicion
    SET total_parejas = total_parejas + 1,
        parejas_juntas = parejas_juntas + (NEW.decision_final = 'J'),
        parejas_separadas = parejas_separadas + (NEW.decision_final = 'S'),
        tiempo_medio_relacion = (tiempo_medio_relacion * (total_parejas - 1) + NEW.tiempo_juntos) / total_parejas
    WHERE id_edicion = id_edicion;
END //

CREATE TRIGGER actualizar_estadisticas_update
AFTER UPDATE ON parejas
FOR EACH ROW
BEGIN
    DECLARE id_edicion INT;
    SELECT id_edicion INTO id_edicion FROM concursantes WHERE id = NEW.id_chico LIMIT 1;
    
    UPDATE estadisticas_parejas_edicion
    SET parejas_juntas = parejas_juntas + (NEW.decision_final = 'J') - (OLD.decision_final = 'J'),
        parejas_separadas = parejas_separadas + (NEW.decision_final = 'S') - (OLD.decision_final = 'S'),
        tiempo_medio_relacion = (tiempo_medio_relacion * total_parejas - OLD.tiempo_juntos + NEW.tiempo_juntos) / total_parejas
    WHERE id_edicion = id_edicion;
END //

CREATE TRIGGER actualizar_estadisticas_delete
AFTER DELETE ON parejas
FOR EACH ROW
BEGIN
    DECLARE id_edicion INT;
    SELECT id_edicion INTO id_edicion FROM concursantes WHERE id = OLD.id_chico LIMIT 1;
    
    UPDATE estadisticas_parejas_edicion
    SET total_parejas = total_parejas - 1,
        parejas_juntas = parejas_juntas - (OLD.decision_final = 'J'),
        parejas_separadas = parejas_separadas - (OLD.decision_final = 'S'),
        tiempo_medio_relacion = IF(total_parejas > 1, (tiempo_medio_relacion * total_parejas - OLD.tiempo_juntos) / (total_parejas - 1), 0)
    WHERE id_edicion = id_edicion;
END //

DELIMITER ;
