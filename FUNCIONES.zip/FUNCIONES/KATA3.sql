DELIMITER //

DROP FUNCTION IF EXISTS porcentaje_parejas_juntas //

CREATE FUNCTION porcentaje_parejas_juntas(edicion_id INT) 
RETURNS DECIMAL(5,2)
DETERMINISTIC
BEGIN
    DECLARE total_parejas INT;
    DECLARE parejas_juntas INT;
    DECLARE porcentaje DECIMAL(5,2);
    
    SELECT COUNT(*) INTO total_parejas
    FROM parejas p
    JOIN concursantes c ON p.id_chico = c.id
    WHERE c.id_edicion = edicion_id;
    
    SELECT COUNT(*) INTO parejas_juntas
    FROM parejas p
    JOIN concursantes c ON p.id_chico = c.id
    WHERE c.id_edicion = edicion_id AND p.decision_final = 'J';
    
    IF total_parejas = 0 THEN
        RETURN 0;
    ELSE
        SET porcentaje = (parejas_juntas / total_parejas) * 100;
        RETURN porcentaje;
    END IF;
END //

DELIMITER ;
