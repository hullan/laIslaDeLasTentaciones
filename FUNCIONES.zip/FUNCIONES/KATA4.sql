DELIMITER //

DROP FUNCTION IF EXISTS audiencia_media_edicion //

CREATE FUNCTION audiencia_media_edicion(edicion_id INT) 
RETURNS DECIMAL(10,2)
READS SQL DATA
BEGIN
    DECLARE media DECIMAL(10,2);
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        RETURN -1;
    END;
    
    SELECT AVG(audiencia) INTO media
    FROM episodios
    WHERE id_edicion = edicion_id;
    
    IF media IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No hay episodios para esta edición';
    END IF;
    
    RETURN media;
END //

DELIMITER ;
