DELIMITER //

DROP FUNCTION IF EXISTS total_concursantes //

CREATE FUNCTION total_concursantes(edicion_id INT) 
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE total INT;
    
    SELECT COUNT(*) INTO total
    FROM concursantes
    WHERE id_edicion = edicion_id;
    
    RETURN total;
END //

DELIMITER ;
