DELIMITER //

DROP FUNCTION IF EXISTS duracion_media_relaciones //

CREATE FUNCTION duracion_media_relaciones(edicion_id INT) 
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE media DECIMAL(10,2);
    
    SELECT AVG(p.tiempo_juntos) INTO media
    FROM parejas p
    JOIN concursantes c ON p.id_chico = c.id
    WHERE c.id_edicion = edicion_id;
    
    RETURN COALESCE(media, 0);
END //

DELIMITER ;
