DELIMITER //

DROP FUNCTION IF EXISTS informe_estadisticas_edicion //

CREATE FUNCTION informe_estadisticas_edicion(edicion_id INT) 
RETURNS TEXT
READS SQL DATA
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE concursante_id INT;
    DECLARE concursante_nombre VARCHAR(255);
    DECLARE concursante_edad INT;
    DECLARE total_concursantes INT DEFAULT 0;
    DECLARE edad_media DECIMAL(5,2) DEFAULT 0;
    DECLARE parejas_juntas INT DEFAULT 0;
    DECLARE parejas_separadas INT DEFAULT 0;
    DECLARE pretendientes_expulsados INT DEFAULT 0;
    DECLARE informe TEXT DEFAULT '';
    
    DECLARE cur CURSOR FOR 
        SELECT id, nombre, edad 
        FROM concursantes 
        WHERE id_edicion = edicion_id;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO concursante_id, concursante_nombre, concursante_edad;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SET total_concursantes = total_concursantes + 1;
        SET edad_media = edad_media + concursante_edad;
        
        IF EXISTS (SELECT 1 FROM parejas WHERE (id_chico = concursante_id OR id_chica = concursante_id) AND decision_final = 'J') THEN
            SET parejas_juntas = parejas_juntas + 1;
        ELSEIF EXISTS (SELECT 1 FROM parejas WHERE (id_chico = concursante_id OR id_chica = concursante_id) AND decision_final = 'S') THEN
            SET parejas_separadas = parejas_separadas + 1;
        END IF;
        
        IF EXISTS (SELECT 1 FROM pretendientes WHERE id = concursante_id AND fecha_expulsion IS NOT NULL) THEN
            SET pretendientes_expulsados = pretendientes_expulsados + 1;
        END IF;
    END LOOP;
    
    CLOSE cur;
    
    IF total_concursantes > 0 THEN
        SET edad_media = edad_media / total_concursantes;
    END IF;
    
    SET informe = CONCAT(
        'Edición: ', edicion_id, '\n',
        'Total concursantes: ', total_concursantes, '\n',
        'Edad media: ', ROUND(edad_media, 2), '\n',
        'Parejas juntas: ', parejas_juntas, '\n',
        'Parejas separadas: ', parejas_separadas, '\n',
        'Pretendientes expulsados: ', pretendientes_expulsados
    );
    
    RETURN informe;
END //

DELIMITER ;
